FC-100 flight controller - demo Gerber set (fictional).
4 layers, 100 x 80 mm, 1.60 mm, ENIG, 1 oz, 50 ohm single-ended on L1/L4.
Files: GKO outline, GTL/G2L/G3L/GBL copper, GTS/GBS mask, GTO silk, DRL Excellon drill.
